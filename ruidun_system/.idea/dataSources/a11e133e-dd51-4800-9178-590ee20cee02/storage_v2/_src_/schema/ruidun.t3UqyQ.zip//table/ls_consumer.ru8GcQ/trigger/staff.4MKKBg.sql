create trigger staff
  after INSERT
  on ls_consumer
  for each row
  begin
insert into tb_staff(id, sysid, group_number, name, sex, age, address, phone, id_card, time, company, id_organ, department_id, is_used, part_id) values(new.card_no, new.sysid, new.group_number, new.names, new.gender, new.age, new.address, new.phone, new.id_number, new.start_date, new.unit, new.id_organ, new.group_number, new.is_used, new.part_id);
end;

