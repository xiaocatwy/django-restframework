create trigger locationcard
  after INSERT
  on ls_location_card
  for each row
  begin
insert into tb_location_card(id, sysid, card_id, uuid, utype, status, time) values(new.my_uuid, new.sysid, new.card_id, new.uuid, new.utype, new.status, new.update_time);
end;

