create trigger staffrecord
  after INSERT
  on ls_swipe_record
  for each row
  begin
insert into tb_staff_record(id, sysid, zone_name, device_name, names, group_number, inouts, time, card_number, part_id) values(new.uuid, new.sysid, new.zone_name, new.device_name, new.names, new.group_number, new.inouts, new.update_time, new.card_no, new.part_id);
end;

