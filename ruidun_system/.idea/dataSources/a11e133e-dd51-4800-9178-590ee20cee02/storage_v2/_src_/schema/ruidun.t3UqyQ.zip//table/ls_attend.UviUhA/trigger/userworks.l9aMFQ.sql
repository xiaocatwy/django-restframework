create trigger userworks
  after INSERT
  on ls_attend
  for each row
  begin
insert into tb_userworks(id, sysid, time, staff_id, work_time, enter_time, leave_time, part_id) values(new.uuid, new.sysid, new.in_datetime, new.card_no, new.working_msecs, new.in_datetime, new.out_datetime, new.part_id);
end;

