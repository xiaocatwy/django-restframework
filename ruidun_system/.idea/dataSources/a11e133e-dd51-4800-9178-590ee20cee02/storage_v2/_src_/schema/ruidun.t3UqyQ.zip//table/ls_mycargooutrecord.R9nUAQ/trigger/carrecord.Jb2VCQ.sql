create trigger carrecord
  after INSERT
  on ls_mycargooutrecord
  for each row
  begin
insert into tb_car_record(id, sysid, cardid, cardnumber, inplace, intime, outplace, outtime, part_id) values(new.uuid, new.sysid, new.cardid, new.cardnumber, new.inplace, new.intime, new.outplace, new.outtime, new.part_id);
end;

