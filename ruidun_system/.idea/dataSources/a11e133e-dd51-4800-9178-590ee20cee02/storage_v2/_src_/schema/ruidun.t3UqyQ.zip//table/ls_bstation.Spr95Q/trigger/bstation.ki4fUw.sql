create trigger bstation
  after INSERT
  on ls_bstation
  for each row
  begin
insert into tb_bs_tation(id, sysid, bs_addr, bs_posx, bs_posy, bs_posz, part_id) values(new.uuid, new.sysid, new.bs_addr, new.bs_posx, new.bs_posy, new.bs_posz, new.part_id);
end;

