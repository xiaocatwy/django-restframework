create trigger carinfo
  after INSERT
  on ls_myfaxingssue
  for each row
  begin
insert into tb_car_msg(id, sysid, cphm, clys, clxh, part_id) values(new.uuid, new.sysid, new.cphm, new.clys, new.clxh, new.part_id);
end;

