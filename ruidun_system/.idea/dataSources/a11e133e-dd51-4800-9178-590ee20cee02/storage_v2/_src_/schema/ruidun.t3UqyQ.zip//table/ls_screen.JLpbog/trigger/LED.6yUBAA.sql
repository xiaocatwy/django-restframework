create trigger LED
  after INSERT
  on ls_screen
  for each row
  begin
insert into tb_led_info(id, sysid, area_name, nScreenNo, pScreenName, nWidth, nHeight, nScreenType, nPixelMode, ip, port, is_used, part_id) values(new.uuid, new.sysid, new.area_name, new.nScreenNo, new.pScreenName, new.nWidth, new.nHeight, new.nScreenType, new.nPixelMode, new.pSocketIP, new.nSocketPort, new.is_used, new.part_id);
end;

