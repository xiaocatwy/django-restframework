create trigger department
  after INSERT
  on ls_group
  for each row
  begin
insert into tb_department(id, sysid, department, group_name, update_status, is_used, part_id) values(new.number, new.sysid, new.department, new.group_name, new.update_status, new.is_used, new.part_id);
end;

